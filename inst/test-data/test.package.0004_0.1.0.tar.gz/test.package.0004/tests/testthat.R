library(testthat)
library(test.package.0004)

test_check("test.package.0004")
